<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tokoBunga;
use Database\Seeders\tokoBungaSeeder;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class tokoBungaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        $toko_bungas = tokoBunga::all();
        //dd($toko_bungas);
        return view('index', compact('toko_bungas'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        //dd($request->all());
        // Validasi input data
        $request->validate([
            'nama' => 'required',
            'jenis' => 'required',
            'harga' => 'required|numeric',
        ]);

        // Create a new tokoBunga instance and save it to the database
        tokoBunga::create([
            'nama' => $request-> nama,
            'jenis' => $request-> jenis,
            'harga' => $request-> harga,
        ]);

        // Redirect to a success page or back to the form with a success message
        return redirect()->route('tokoBunga')->with('success', 'Data bunga berhasil disimpan');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id) : View
    {
        $toko_bungas = tokoBunga::findOrfail($id);
        return view('edit', compact('toko_bungas'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id) : RedirectResponse
    {
     $this->validate($request, [
        'nama' => 'required',
        'jenis' => 'required',
        'harga' => 'required|numeric'
     ]);   

     $toko_bungas = tokoBunga::findOrFail($id);
     $toko_bungas->update([
        'nama' => $request->nama,
        'jenis' => $request->jenis,
        'harga' => $request->harga
     ]);
     return redirect()->route('tokoBunga')->with(['success' => 'data berhasil di ubah']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
