<?php

namespace Database\Seeders;

use App\Models\tokoBunga;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class tokoBungaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * @return void
     */
    public function run()
    {
        tokoBunga::create([
            'nama' => 'Bunga Lily',
            'jenis' => 'Bunga Hias',
            'harga' => '250000'
        ]);
    }
}
