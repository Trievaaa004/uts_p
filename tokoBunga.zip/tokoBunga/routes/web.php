<?php

use App\Http\Controllers\tokoBungaController;
use App\Models\tokoBunga;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/login', 'App\Http\Controllers\LoginController@showLoginForm')->name('login');
// Route::post('login', 'App\Http\Controllers\LoginController@Login');
//Route::get('/toko-bunga', [TokoBungaController::class, 'index'])->name('tokoBunga');
Route::get('/toko', [tokoBungaController::class, 'index'])->name('tokoBunga');
Route::post('/toko', [tokoBungaController::class, 'store'])->name('tokoBungas.store');
Route::get('/toko/create', [tokoBungaController::class, 'create'])->name('tokoBungas.create');
Route::post('/toko/{toko}', [tokoBungaController::class, 'update'])->name('tokoBungas.update');
Route::delete('/toko/{toko}', [tokoBungaController::class, 'destroy'])->name('tokoBungas.destroy');
Route::get('/toko/{toko}/edit', [tokoBungaController::class, 'edit'])->name('tokoBungas.edit');
Route::resource('tokoBungas', tokoBungaController::class);

